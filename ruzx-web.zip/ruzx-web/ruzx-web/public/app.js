const modal = document.getElementById('modal-beli');
const modalJudul = document.getElementById('modal-judul');
const modalHarga = document.getElementById('modal-harga');
const formBeli = document.getElementById('form-beli');
const tombolTutup = document.getElementById('modal-tutup');

let produkDipilih = null;

function formatRupiah(angka) {
  return 'Rp ' + Number(angka).toLocaleString('id-ID');
}

document.querySelectorAll('.btn--beli').forEach((tombol) => {
  tombol.addEventListener('click', () => {
    produkDipilih = {
      slug: tombol.dataset.slug,
      nama: tombol.dataset.nama,
      harga: tombol.dataset.harga
    };
    modalJudul.textContent = produkDipilih.nama;
    modalHarga.textContent = formatRupiah(produkDipilih.harga);
    modal.hidden = false;
  });
});

function tutupModal() {
  modal.hidden = true;
  formBeli.reset();
}

tombolTutup.addEventListener('click', tutupModal);
modal.addEventListener('click', (e) => {
  if (e.target === modal) tutupModal();
});

formBeli.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!produkDipilih) return;

  const tombolSubmit = formBeli.querySelector('button[type="submit"]');
  tombolSubmit.disabled = true;
  tombolSubmit.textContent = 'Memproses...';

  const payload = {
    slug: produkDipilih.slug,
    buyer_name: document.getElementById('input-nama').value,
    buyer_email: document.getElementById('input-email').value,
    buyer_phone: document.getElementById('input-phone').value
  };

  try {
    const res = await fetch('/api/transaction', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.message || 'Gagal membuat transaksi');
    }

    tutupModal();

    window.snap.pay(data.token, {
      onSuccess: () => {
        alert('Pembayaran berhasil. File akan dikirim ke kontak yang kamu daftarkan.');
      },
      onPending: () => {
        alert('Pembayaran tertunda. Selesaikan pembayaran untuk menerima file.');
      },
      onError: () => {
        alert('Pembayaran gagal. Silakan coba lagi.');
      },
      onClose: () => {
        console.log('Jendela pembayaran ditutup oleh pengguna.');
      }
    });
  } catch (err) {
    alert(err.message);
  } finally {
    tombolSubmit.disabled = false;
    tombolSubmit.textContent = 'Lanjut ke pembayaran';
  }
});
