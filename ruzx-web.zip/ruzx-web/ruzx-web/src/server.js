const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
require('dotenv').config();

const db = require('./db');
const midtrans = require('./midtrans');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Kirim client key ke frontend tanpa menyentuh server key
app.get('/api/config', (req, res) => {
  res.json({ clientKey: midtrans.clientKey });
});

app.get('/api/products', async (req, res) => {
  try {
    const products = await db.getAllProducts();
    res.json(products);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mengambil daftar produk' });
  }
});

// Membuat transaksi baru dan mengembalikan snap token ke frontend
app.post('/api/transaction', async (req, res) => {
  try {
    const { slug, buyer_name, buyer_email, buyer_phone } = req.body;
    const product = await db.getProductBySlug(slug);

    if (!product) {
      return res.status(404).json({ message: 'Produk tidak ditemukan' });
    }

    const order_id = `RUZX-${product.slug}-${Date.now()}`;

    const transaction = await midtrans.createTransaction({
      order_id,
      price: product.price,
      product_name: product.name,
      buyer_name,
      buyer_email,
      buyer_phone
    });

    await db.createOrder({
      order_id,
      product_slug: product.slug,
      product_name: product.name,
      price: product.price,
      buyer_name,
      buyer_email,
      buyer_phone,
      snap_token: transaction.token
    });

    res.json({ token: transaction.token, order_id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal membuat transaksi' });
  }
});

// Endpoint notifikasi Midtrans (atur URL ini di dashboard Midtrans)
app.post('/api/notification', async (req, res) => {
  try {
    const notification = req.body;
    const statusResponse = await midtrans.getTransactionStatus(notification.order_id);

    const { order_id, transaction_status, fraud_status } = statusResponse;
    let status = 'pending';

    if (transaction_status === 'capture' || transaction_status === 'settlement') {
      status = fraud_status === 'accept' || !fraud_status ? 'paid' : 'pending';
    } else if (transaction_status === 'deny' || transaction_status === 'cancel') {
      status = 'failed';
    } else if (transaction_status === 'expire') {
      status = 'expired';
    }

    await db.updateOrderStatus(order_id, status);
    res.status(200).send('OK');
  } catch (err) {
    console.error(err);
    res.status(500).send('Gagal memproses notifikasi');
  }
});

// Cek status order dari frontend (dipanggil setelah pop-up Snap ditutup)
app.get('/api/order/:order_id', async (req, res) => {
  try {
    const order = await db.getOrder(req.params.order_id);
    if (!order) return res.status(404).json({ message: 'Order tidak ditemukan' });
    res.json(order);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Gagal mengambil status order' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Ruzx Store berjalan di port ${PORT}`);
});
