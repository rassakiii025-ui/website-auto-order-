const midtransClient = require('midtrans-client');
require('dotenv').config();

const snap = new midtransClient.Snap({
  isProduction: process.env.MIDTRANS_IS_PRODUCTION === 'true',
  serverKey: process.env.MIDTRANS_SERVER_KEY,
  clientKey: process.env.MIDTRANS_CLIENT_KEY
});

const coreApi = new midtransClient.CoreApi({
  isProduction: process.env.MIDTRANS_IS_PRODUCTION === 'true',
  serverKey: process.env.MIDTRANS_SERVER_KEY,
  clientKey: process.env.MIDTRANS_CLIENT_KEY
});

async function createTransaction({ order_id, price, product_name, buyer_name, buyer_email, buyer_phone }) {
  const parameter = {
    transaction_details: {
      order_id,
      gross_amount: price
    },
    item_details: [
      {
        id: order_id,
        price,
        quantity: 1,
        name: product_name.substring(0, 50)
      }
    ],
    customer_details: {
      first_name: buyer_name || 'Pembeli',
      email: buyer_email || undefined,
      phone: buyer_phone || undefined
    },
    credit_card: {
      secure: true
    }
  };

  const transaction = await snap.createTransaction(parameter);
  return transaction;
}

// Dipakai saat Midtrans mengirim notifikasi status pembayaran
async function getTransactionStatus(order_id) {
  return coreApi.transaction.status(order_id);
}

module.exports = {
  createTransaction,
  getTransactionStatus,
  clientKey: process.env.MIDTRANS_CLIENT_KEY
};
