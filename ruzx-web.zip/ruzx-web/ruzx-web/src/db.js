const mysql = require('mysql2/promise');
require('dotenv').config();

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT || 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

async function getProductBySlug(slug) {
  const [rows] = await pool.query('SELECT * FROM products WHERE slug = ? LIMIT 1', [slug]);
  return rows[0] || null;
}

async function getAllProducts() {
  const [rows] = await pool.query('SELECT * FROM products ORDER BY id ASC');
  return rows;
}

async function createOrder(order) {
  const { order_id, product_slug, product_name, price, buyer_name, buyer_email, buyer_phone, snap_token } = order;
  await pool.query(
    `INSERT INTO orders (order_id, product_slug, product_name, price, buyer_name, buyer_email, buyer_phone, snap_token, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')`,
    [order_id, product_slug, product_name, price, buyer_name, buyer_email, buyer_phone, snap_token]
  );
}

async function updateOrderStatus(order_id, status) {
  await pool.query('UPDATE orders SET status = ? WHERE order_id = ?', [status, order_id]);
}

async function getOrder(order_id) {
  const [rows] = await pool.query('SELECT * FROM orders WHERE order_id = ? LIMIT 1', [order_id]);
  return rows[0] || null;
}

module.exports = {
  pool,
  getProductBySlug,
  getAllProducts,
  createOrder,
  updateOrderStatus,
  getOrder
};
