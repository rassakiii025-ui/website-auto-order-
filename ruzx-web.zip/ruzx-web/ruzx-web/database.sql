-- Database untuk Ruzx Store
CREATE DATABASE IF NOT EXISTS ruzx_web CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ruzx_web;

-- Tabel produk
CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(100) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  price INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel order / transaksi
CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id VARCHAR(100) NOT NULL UNIQUE,
  product_slug VARCHAR(100) NOT NULL,
  product_name VARCHAR(150) NOT NULL,
  price INT NOT NULL,
  buyer_name VARCHAR(150),
  buyer_email VARCHAR(150),
  buyer_phone VARCHAR(30),
  status ENUM('pending', 'paid', 'failed', 'expired') DEFAULT 'pending',
  snap_token VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Data 3 produk Ruzx Store
INSERT INTO products (slug, name, description, price) VALUES
('bot-wa-jaga-grup', 'Script Bot WA Jaga Grup', 'Bot WhatsApp untuk menjaga dan mengelola grup secara otomatis.', 25000),
('bot-auto-order-telegram', 'Script Bot Auto Order Telegram', 'Bot Telegram untuk menerima dan memproses order secara otomatis.', 30000),
('bot-bug-wa-adawong-x-ruzx', 'Script Bot Bug WA Adawong X Ruzx', 'Script bug WhatsApp kolaborasi Adawong X Ruzx.', 30000)
ON DUPLICATE KEY UPDATE name = VALUES(name), price = VALUES(price);
